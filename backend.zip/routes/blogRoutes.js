const { checkToken } = require('../auth/token_validation')
const blogController=require('../controllers/blogController')
const { upload } = require('../upload/UploadFile')

const router=require('express').Router()

router.get('/get',blogController.getblog)
router.post('/create',upload.any('image'),blogController.addblog)


router.get('/get/:id',blogController.getblogById)
router.put('/update/:id',upload.any('image'),blogController.updateblog)
router.delete('/delete/:id',blogController.deleteblog)


module.exports=router

