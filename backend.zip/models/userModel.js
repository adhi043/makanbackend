module.exports=(sequelize,DataTypes)=>{
    const User=sequelize.define('user',{
        signAs:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        city:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        phone:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        fullName:{
            type: DataTypes.STRING,
            allowNull: false,
        },
        email:{
            type: DataTypes.STRING,
            allowNull: false,
        },
        password:{
            type: DataTypes.STRING,
            allowNull: false,
        },
        agencyName:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        serviceArea:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        agencyDescription:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        agencyLogo:{
            type: DataTypes.STRING,
            allowNull: true,
        },
        status:{
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
    })

    return User

}