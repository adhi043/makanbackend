module.exports={
    // HOST: "makanapis.makkaan.com.pk",
    // HOST: "makanapis.sargodhacci-org.com",
      HOST: "localhost",
    PORT: "8000",
    // USER: "admsccio_makanapis",
      USER: "root",
    // PASSWORD: "Lighthouse078",
      PASSWORD: "",
    // DB: "admsccio_makanapis",
      DB: "makan",
    dialect: "mysql",
    KEY_NAME: "cpAdhi099",
    EMAIL:'cpearnings@gmail.com',
    PASS:'bjzjvfmxlvavnibd',
    mainUrl: "http://159.89.174.139:8000/",
    // mainUrl: 'http://localhost:8000/',

    pool:{
        max:5,
        min:0,
        idle:10000,
        acquire:30000
    }
}