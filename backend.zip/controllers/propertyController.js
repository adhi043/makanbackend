const db = require('../models');
const { hashSync, genSaltSync } = require('bcrypt')
const dbConfig = require('../config/dbConfig.js');
const { sendMail } = require('../otp/OTPVerification');
const { sign } = require('jsonwebtoken')
const nodemailer = require('nodemailer');
const { Op } = require('sequelize');


// create main model
const Property = db.property;

// main work




// 1.create product
const addproperty = async (req, res) => {

    try {

        console.log(req.files)

        let info = {
            image: req.files === undefined ? '' : req.files.map(file=>dbConfig.mainUrl + file.filename),
            video: req.body.video,
            purpose: req.body.purpose,
            userId: req.body.userId,
            property: req.body.property,
            type: req.body.type,
            feature: req.body.feature,
            city: req.body.city,
            location: req.body.location,
            size: req.body.size,
            email: req.body.email,
            price: req.body.price,
            beds: req.body.beds,
            baths: req.body.baths,
            title: req.body.title,
            description: req.body.description,
            phone: req.body.phone,
            landline: req.body.landline,
        }

        const property = await Property.create(info)
        res.status(200).json({
            status: 'ok',
            data: property,
        })



    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}



// 2.get all products
const getproperty = async (req, res) => {

    try {


        let property = await Property.findAll({})
        res.status(200).json({
            status: 'ok',
            data: property,
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}


// 3.get product by id
const getpropertyById = async (req, res) => {


    try {
        let id = req.params.id

        let property = await Property.findOne({
            where: { id: id }
        })
        res.status(200).json({
            status: 'ok',
            data: property
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}



// 3.get product by id
const getpropertyByCity = async (req, res) => {


    try {
        let id = req.params.id

        let property = await Property.findAll({
            where: { city: id }
        })
        res.status(200).json({
            status: 'ok',
            data: property
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}




// 3.get product by id
const filterpropertyById = async (req, res) => {
    try {
      const { city, title, type, minPrice, maxPrice, minArea, maxArea, beds } = req.body;
      
      // Build the filter conditions
      const where = {};
      
      if (city) {
        where.city = city;
      }
      
      if (title) {
        where.title = {
          [Op.like]: `%${title}%`,
        };
      }
      
      if (type && type!=='Any Type') {
        where.type = type;
      }
      
      if (minPrice && maxPrice) {
        where.price = {
          [Op.between]: [parseInt(minPrice), parseInt(maxPrice)],
        };
      } else if (minPrice) {
        where.price = {
          [Op.gte]: parseInt(minPrice),
        };
      } else if (maxPrice) {
        where.price = {
          [Op.lte]: parseInt(maxPrice),
        };
      }
      
      if (minArea && maxArea) {
        where.size = {
          [Op.between]: [parseInt(minArea), parseInt(maxArea)],
        };
      } else if (minArea) {
        where.size = {
          [Op.gte]: parseInt(minArea),
        };
      } else if (maxArea) {
        where.size = {
          [Op.lte]: parseInt(maxArea),
        };
      }
      
      if (beds && beds!=='All Beds') {
        where.beds = beds;
      }
      
      // Find the properties that match the filter conditions
      const properties = await Property.findAll({
        where,
      });
      
      res.status(200).json({
        status: 'ok',
        data: properties
      });
    } catch (err) {
      res.status(500).json({
        error: err.message
      });
    }
  };
  


// 4.update product

const updateproperty = async (req, res) => {

    try {
        let id = req.params.id


        let getproperty = await Property.findOne({
            where: { id: id }
        })



        const property = await Property.update({ ...req.body }, {
            where: { id: id }
        }
        )
        res.status(200).json({
            status: 'ok',
            data: property
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }



}


// 5.delete product

const deleteproperty = async (req, res) => {

    try {
        let id = req.params.id

        const property = await Property.destroy({
            where: { id: id }
        })
        res.status(200).json({
            status: 'ok',
            data: property
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }


}





module.exports = {
    addproperty,
    getproperty,
    getpropertyById,
    updateproperty,
    deleteproperty,
    filterpropertyById,
    getpropertyByCity
}


