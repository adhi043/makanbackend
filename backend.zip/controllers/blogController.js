const db = require('../models');
const { hashSync, genSaltSync } = require('bcrypt')
const dbConfig = require('../config/dbConfig.js');
const { sendMail } = require('../otp/OTPVerification');
const { sign } = require('jsonwebtoken')
const nodemailer = require('nodemailer');
const { Op } = require('sequelize');


// create main model
const Blog = db.blog;

// main work




// 1.create product
const addblog = async (req, res) => {

    try {

        let info = {
            name: req.body.name,
            image: req.files === undefined ? '' : dbConfig.mainUrl + req.files[0].filename,
            description: req.body.description,
        }

        const blog = await Blog.create(info)
        return res.status(200).json({
            status: 'ok',
            data: blog,
        })



    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}



// 2.get all products
const getblog = async (req, res) => {

    try {


        let blog = await Blog.findAll({})
        res.status(200).json({
            status: 'ok',
            data: blog,
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}


// 3.get product by id
const getblogById = async (req, res) => {


    try {
        let id = req.params.id

        let blog = await Blog.findOne({
            where: { id: id }
        })
        res.status(200).json({
            status: 'ok',
            data: blog
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}


// 4.update product

const updateblog = async (req, res) => {

    try {
        let id = req.params.id


        let getblog = await Blog.findOne({
            where: { id: id }
        })



        const blog = await Blog.update({ ...req.body }, {
            where: { id: id }
        }
        )
        res.status(200).json({
            status: 'ok',
            data: blog
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }



}


// 5.delete product

const deleteblog = async (req, res) => {

    try {
        let id = req.params.id

        const blog = await Blog.destroy({
            where: { id: id }
        })
        res.status(200).json({
            status: 'ok',
            data: blog
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }


}





module.exports = {
    addblog,
    getblog,
    getblogById,
    updateblog,
    deleteblog,
}


