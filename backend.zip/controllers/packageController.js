const db = require('../models');
const { hashSync, genSaltSync } = require('bcrypt')
const dbConfig = require('../config/dbConfig.js');
const { sendMail } = require('../otp/OTPVerification');
const { sign } = require('jsonwebtoken')
const nodemailer = require('nodemailer');
const { Op } = require('sequelize');


// create main model
const Package = db.package;

// main work




// 1.create product
const addpackage = async (req, res) => {

    try {

        let info = {
            title: req.body.title,
            description: req.body.description,
            duration: req.body.duration,
            price: req.body.price,
            addProperty: req.body.addProperty,
        }

        const package = await Package.create(info)
        return res.status(200).json({
            status: 'ok',
            data: package,
        })



    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}



// 2.get all products
const getpackage = async (req, res) => {

    try {


        let package = await Package.findAll({})
        res.status(200).json({
            status: 'ok',
            data: package,
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}


// 3.get product by id
const getpackageById = async (req, res) => {


    try {
        let id = req.params.id

        let package = await Package.findOne({
            where: { id: id }
        })
        res.status(200).json({
            status: 'ok',
            data: package
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }

}


// 4.update product

const updatepackage = async (req, res) => {

    try {
        let id = req.params.id


        let getpackage = await Package.findOne({
            where: { id: id }
        })



        const package = await Package.update({ ...req.body }, {
            where: { id: id }
        }
        )
        res.status(200).json({
            status: 'ok',
            data: package
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }



}


// 5.delete product

const deletepackage = async (req, res) => {

    try {
        let id = req.params.id

        const package = await Package.destroy({
            where: { id: id }
        })
        res.status(200).json({
            status: 'ok',
            data: package
        })
    } catch (err) {
        res.status(500).json({
            error: err.message
        })
    }


}





module.exports = {
    addpackage,
    getpackage,
    getpackageById,
    updatepackage,
    deletepackage,
}


